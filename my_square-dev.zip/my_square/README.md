# Welcome to My Square
***

## Task

This section can describe how the project is scored or evaluated, if applicable. For example, "This project is evaluated based on functionality, code efficiency, and meeting the requirements set forth in the task description."

## Description

Provide a summary of the task that the project aims to solve or accomplish. For example, "The task of this project is to develop a fully-functional web application that allows users to manage their personal finances effectively."

## Installation

A detailed explanation of your project. For example, "This project is a personal finance manager application that lets users track their spending, categorize expenses, and visualize their financial habits through graphs and charts."

## Usage

Instructions for setting up the project. For example, "To install this project locally, first clone the repository:
git clone https://github.com/username/project.git
Then, install dependencies:
npm install
After that, you can run the project using:
npm start"
./my_project argument1 argument2
```

### The Core Team
Explain how to use the project. For example, "Once the application is running, visit localhost:3000 in your browser. You can start by creating an account and entering your first expense. The dashboard will show your spending trends."


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
